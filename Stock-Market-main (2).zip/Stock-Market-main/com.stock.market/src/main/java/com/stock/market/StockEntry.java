package com.stock.market;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class StockEntry {
	// BigDecimal
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int stockEntryId;
	LocalDateTime entryDateTime; // Future work: <property name="hibernate.jdbc.time_zone" value="UTC"/> or
									// spring.jpa.properties.hibernate.jdbc.time_zone=UTC
	private BigDecimal high;
	private BigDecimal low;
	private BigDecimal openingPrice;
	private BigDecimal closingPrice;

	// Constructor
	public StockEntry(LocalDateTime entryDateTime, BigDecimal high, BigDecimal low, BigDecimal openingPrice,
			BigDecimal closingPrice) {
		super();
		this.entryDateTime = entryDateTime;
		this.high = high;
		this.low = low;
		this.openingPrice = openingPrice;
		this.closingPrice = closingPrice;
	}

	// Getters and Setters
	public int getStockEntryId() {
		return stockEntryId;
	}

	public void setStockEntryId(int stockEntryId) {
		this.stockEntryId = stockEntryId;
	}

	public LocalDateTime getEntryDateTime() {
		return entryDateTime;
	}

	public void setEntryDateTime(LocalDateTime entryDateTime) {
		this.entryDateTime = entryDateTime;
	}

	public BigDecimal getHigh() {
		return high;
	}

	public void setHigh(BigDecimal high) {
		this.high = high;
	}

	public BigDecimal getLow() {
		return low;
	}

	public void setLow(BigDecimal low) {
		this.low = low;
	}

	public BigDecimal getOpeningPrice() {
		return openingPrice;
	}

	public void setOpeningPrice(BigDecimal openingPrice) {
		this.openingPrice = openingPrice;
	}

	public BigDecimal getClosingPrice() {
		return closingPrice;
	}

	public void setClosingPrice(BigDecimal closingPrice) {
		this.closingPrice = closingPrice;
	}

	// toString()
	@Override
	public String toString() {
		return "StockEntry [stockEntryId=" + stockEntryId + ", entryDateTime=" + entryDateTime + ", high=" + high
				+ ", low=" + low + ", openingPrice=" + openingPrice + ", closingPrice=" + closingPrice + "]";
	}

}
