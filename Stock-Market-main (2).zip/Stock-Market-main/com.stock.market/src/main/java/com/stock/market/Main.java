package com.stock.market;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {
	
	public static void main(String[] args) {
		 
		/* Create EntityManagerFactory */
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("maintest");
	
		
		/* Create EntityManager */
		EntityManager em = emf.createEntityManager();
		
		/* Create and populate Entity */
		ArrayList<Role> r1= new ArrayList<Role>(1);
		ArrayList<Role> r2= new ArrayList<Role>(2);
		ArrayList<Role> r3= new ArrayList<Role>(2);
		ArrayList<Role> r4= new ArrayList<Role>(2);
		
		User user = new User("Aman", "Aman@1", "English", "aman@outlook.com", 9800000076l , r1 );
		User userc1 = new User("Naveen", "naveen@c1", "English", "naveen@outlook.com", 9800000076l , r2 );
		User userc2 = new User("Harleen", "harleen@c2", "English", "harleen@outlook.com", 9800000076l , r3 );
		User userc3 = new User("Ragini", "ragini@c3", "English", "ragini@outlook.com", 9800000076l , r4 );
		
		/* Persist entity */
		em.getTransaction().begin();
		em.persist(user);
		em.persist(userc1);
		em.persist(userc2);
		em.persist(userc3);
		em.getTransaction().commit();
		
		
		
	}

}
