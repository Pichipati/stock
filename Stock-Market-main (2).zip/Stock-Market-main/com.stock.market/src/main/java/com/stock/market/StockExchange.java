package com.stock.market;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class StockExchange {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int exchangeId;
	private String exchangeName;

	@JoinTable
	@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	private List<Stock> stocks;

	// Constructor
	public StockExchange(String exchangeName, List<Stock> stocks) {
		super();
		this.exchangeName = exchangeName;
		this.stocks = stocks;
	}

	// Getters and Setters
	public int getExchangeId() {
		return exchangeId;
	}

	public void setExchangeId(int exchangeId) {
		this.exchangeId = exchangeId;
	}

	public String getExchangeName() {
		return exchangeName;
	}

	public void setExchangeName(String exchangeName) {
		this.exchangeName = exchangeName;
	}

	public List<Stock> getStocks() {
		return stocks;
	}

	public void setStocks(List<Stock> stocks) {
		this.stocks = stocks;
	}

	// toString
	@Override
	public String toString() {
		return "StockExchange [exchangeId=" + exchangeId + ", exchangeName=" + exchangeName + ", stocks=" + stocks
				+ "]";
	}

}
