package com.stock.market;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Stock {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int stockId;
	private String stockName;

	@JoinTable
	@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	private List<StockExchange> stocks;

	@JoinColumn
	@OneToMany(cascade = CascadeType.ALL)
	private List<StockEntry> stockEntry;

	// Constructor
	public Stock(String stockName, List<StockExchange> stocks, List<StockEntry> stockEntry) {
		super();
		this.stockName = stockName;
		this.stocks = stocks;
		this.stockEntry = stockEntry;
	}

	// Getters and setters
	public int getStockId() {
		return stockId;
	}

	public void setStockId(int stockId) {
		this.stockId = stockId;
	}

	public String getStockName() {
		return stockName;
	}

	public void setStockName(String stockName) {
		this.stockName = stockName;
	}

	public List<StockExchange> getStocks() {
		return stocks;
	}

	public void setStocks(List<StockExchange> stocks) {
		this.stocks = stocks;
	}

	public List<StockEntry> getStockEntry() {
		return stockEntry;
	}

	public void setStockEntry(List<StockEntry> stockEntry) {
		this.stockEntry = stockEntry;
	}

	// toString
	@Override
	public String toString() {
		return "Stock [stockId=" + stockId + ", stockName=" + stockName + ", stocks=" + stocks + "]";
	}

}
