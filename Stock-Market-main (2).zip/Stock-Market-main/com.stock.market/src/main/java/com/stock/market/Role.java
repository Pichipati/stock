package com.stock.market;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Role {

	@Id
	private int roleId;
	private String roleName;

	// Constructor
	public Role(int roleId) {
		super();
		this.roleId = roleId;
	}

	// Getters and Setters
	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName() {
		if (this.getRoleId() == 1) {
			this.roleName = "Admin";
			// System.out.println(this.getRoleName());
		}

		else if (this.getRoleId() == 2) {
			this.roleName = "Customer";
			// System.out.println(this.getRoleName());

		}
	}

	// toString()
	@Override
	public String toString() {
		return "Role [roleId=" + roleId + ", roleName=" + roleName + "]";
	}

}
